//
//  ImageCollectionViewCell.swift
//  MarvelApp
//
//  Created by Haitham Gado on 1/6/19.
//  Copyright © 2019 Haitham Gado. All rights reserved.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var CollectionImage: UIImageView!
    
    @IBOutlet weak var imageTitle: UILabel!
    
    
    
}
